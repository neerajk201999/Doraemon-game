# run-run_doremon_game

This is a simple doremon game based on vanilla javascript.
